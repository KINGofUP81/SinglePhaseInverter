*PADS-LIBRARY-PART-TYPES-V9*

ECW-FE2J105Q5 ECWFE2J105Q5 I CAP 7 1 0 0 0
TIMESTAMP 2026.06.09.21.53.40
"Mouser Part Number" 
"Mouser Price/Stock" 
"Manufacturer_Name" Panasonic
"Manufacturer_Part_Number" ECW-FE2J105Q5
"Description" Metallized Polypropylene Film Capacitor MPP, 0.22uF +/-10%, 630V, -40 to 105 (85)C, (31X9X19)
"Datasheet Link" https://industrial.panasonic.com/cdbs/www-data/pdf/RDI0000/ABD0000C202.pdf
"Geometry.Height" 19.5mm
GATE 1 2 0
ECW-FE2J105Q5
1 0 U 1
2 0 U 2

*END*
*REMARK* SamacSys ECAD Model
13219519/2067606/2.50/2/2/Capacitor
