*PADS-LIBRARY-PART-TYPES-V9*

MF0207FRE52-1K RESAD1590W60L630D240 I RES 6 1 0 0 0
TIMESTAMP 2026.06.30.18.20.55
"Mouser Part Number" 603-MF0207FRE52-1K
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/YAGEO/MF0207FRE52-1K?qs=8uu3sA0mUdvCQE3OPmDzOQ%3D%3D
"Manufacturer_Name" Yageo Group
"Manufacturer_Part_Number" MF0207FRE52-1K
"Description" Metal Film Resistors - Through Hole 0.6W 1K Ohm 1%
"Datasheet Link" https://www.yageo.com/upload/media/product/productsearch/datasheet/lr/YAGEO%20MF0_datasheet_2021v1.pdf
GATE 1 2 0
MF0207FRE52-1K
1 0 U 1
2 0 U 2

*END*
*REMARK* SamacSys ECAD Model
16999230/2067606/2.50/2/3/Resistor
