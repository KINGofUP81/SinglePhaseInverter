*PADS-LIBRARY-PART-TYPES-V9*

RC1206FR-07330KL RESC3116X65N I RES 7 1 0 0 0
TIMESTAMP 2026.06.09.22.12.42
"Mouser Part Number" 603-RC1206FR-07330KL
"Mouser Price/Stock" https://www.mouser.com/Search/Refine.aspx?Keyword=603-RC1206FR-07330KL
"Manufacturer_Name" Yageo Group
"Manufacturer_Part_Number" RC1206FR-07330KL
"Description" RESISTOR, 1206 330 KOhm +/-1% 0.25 W
"Datasheet Link" https://componentsearchengine.com/Datasheets/1/RC1206FR-07330KL.pdf
"Geometry.Height" 0.65mm
GATE 1 2 0
RC1206FR-07330KL
1 0 U 1
2 0 U 2

*END*
*REMARK* SamacSys ECAD Model
604269/2067606/2.50/2/0/Resistor
