*PADS-LIBRARY-PART-TYPES-V9*

B72220S0421K101 B72220S0421K101 I ANA 7 1 0 0 0
TIMESTAMP 2026.06.11.15.31.42
"Mouser Part Number" 871-B72220S421K101
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/EPCOS-TDK/B72220S0421K101?qs=dEfas%2FXlABINyZl3zDLnHw%3D%3D
"Manufacturer_Name" TDK
"Manufacturer_Part_Number" B72220S0421K101
"Description" Leaded Disk Varistors, Max. Operating Voltage [AC]=420Vrms, Max. Surge Current Imax(8/20?s,1time)=8000A
"Datasheet Link" https://product.tdk.com/system/files/dam/doc/product/protection/voltage/lead-disk-varistor/data_sheet/70/db/var/siov_leaded_standard.pdf
"Geometry.Height" 29mm
GATE 1 2 0
B72220S0421K101
1 0 U 1
2 0 U 2

*END*
*REMARK* SamacSys ECAD Model
444985/2067606/2.50/2/2/Varistor
