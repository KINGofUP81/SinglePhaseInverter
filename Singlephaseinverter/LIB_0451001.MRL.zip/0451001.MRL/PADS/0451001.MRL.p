*PADS-LIBRARY-PART-TYPES-V9*

0451001.MRL FUSC6127X294N I FUS 7 1 0 0 0
TIMESTAMP 2026.06.09.22.34.11
"Mouser Part Number" 576-0451001.MRL
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Littelfuse/0451001.MRL?qs=bpnLQM2ZShx47p41NnV6fQ%3D%3D
"Manufacturer_Name" LITTELFUSE
"Manufacturer_Part_Number" 0451001.MRL
"Description" Fuse,SMT,very fast acting,451,1A
"Datasheet Link" 
"Geometry.Height" 2.94mm
GATE 1 2 0
0451001.MRL
1 0 U 1
2 0 U 2

*END*
*REMARK* SamacSys ECAD Model
862738/2067606/2.50/2/3/Fuse
