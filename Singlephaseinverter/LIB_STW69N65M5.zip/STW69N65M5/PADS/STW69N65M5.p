*PADS-LIBRARY-PART-TYPES-V9*

STW69N65M5 TO545P515X1560X2445-3P I TRX 7 1 0 0 0
TIMESTAMP 2026.06.30.13.33.55
"Mouser Part Number" 511-STW69N65M5
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/STMicroelectronics/STW69N65M5?qs=RpYEFuZ7GTghVWtKbZMsBA%3D%3D
"Manufacturer_Name" STMicroelectronics
"Manufacturer_Part_Number" STW69N65M5
"Description" STMICROELECTRONICS - STW69N65M5 - MOSFET Transistor, N Channel, 58 A, 650 V, 0.037 ohm, 10 V, 4 V
"Datasheet Link" https://www.st.com/resource/en/datasheet/stfw69n65m5.pdf
"Geometry.Height" 5.15mm
GATE 1 3 0
STW69N65M5
1 0 U G
2 0 U D
3 0 U S

*END*
*REMARK* SamacSys ECAD Model
222568/2067606/2.50/3/2/MOSFET (N-Channel)
