*PADS-LIBRARY-PART-TYPES-V9*

HE1aN-P-DC12V HE1aNPDC12V I RLY 7 1 0 0 0
TIMESTAMP 2026.06.11.16.25.06
"Mouser Part Number" 769-HE1AN-P-DC12V
"Mouser Price/Stock" https://www.mouser.com/Search/Refine.aspx?Keyword=769-HE1AN-P-DC12V
"Manufacturer_Name" Panasonic
"Manufacturer_Part_Number" HE1aN-P-DC12V
"Description" TV-10/TV-15 rated, 1 Form A 30 A, Power relays , 12 V DC , 1 Form A , 160 mA , 75  , 50 to 55 
"Datasheet Link" https://componentsearchengine.com/Datasheets/1/HE1AN-P-DC12V.pdf
"Geometry.Height" 36.6mm
GATE 1 6 0
HE1aN-P-DC12V
A1 0 U N.O.1.1
A4 0 U N.O2.1
A5 0 U COIL_1
A6 0 U COIL_2
B1 0 U N.O.1.2
B4 0 U N.O.2.2

*END*
*REMARK* SamacSys ECAD Model
2659658/2067606/2.50/6/3/Relay or Contactor
