*PADS-LIBRARY-PART-TYPES-V9*

BAT54 SOT95P240X120-3N I ANA 7 1 0 0 0
TIMESTAMP 2026.07.01.07.22.37
"Mouser Part Number" 637-BAT54
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Diotec-Semiconductor/BAT54?qs=OlC7AqGiEDly6dDY2EuTHA%3D%3D
"Manufacturer_Name" Diotec
"Manufacturer_Part_Number" BAT54
"Description" Diode 30 V 200mA Surface Mount SOT-23-3 (TO-236)
"Datasheet Link" https://diotec.com/request/datasheet/bat54.pdf
"Geometry.Height" 1.2mm
GATE 1 3 0
BAT54
3 0 U K
1 0 U A
2 0 U NC

*END*
*REMARK* SamacSys ECAD Model
1291265/2067606/2.50/3/3/Schottky Diode with NC
