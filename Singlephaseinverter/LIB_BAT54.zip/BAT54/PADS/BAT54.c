*PADS-LIBRARY-SCH-DECALS-V9*

STPSC8H065G-TR   32000 32000 97 10 97 10 4 6 0 3 8
TIMESTAMP 2025.01.24.15.07.19
"Default Font"
"Default Font"
400   350   0 8 97 10 "Default Font"
REF-DES
400   250   0 8 97 10 "Default Font"
PART-TYPE
400   -200  0 0 97 10 "Default Font"
*
400   -300  0 0 97 10 "Default Font"
*
COPCLS 4 10 0 -1
200   0    
400   100  
400   -100 
200   0    
OPEN   2 10 0 -1
200   100  
200   -100 
OPEN   2 10 0 -1
100   0    
200   0    
OPEN   2 10 0 -1
500   0    
400   0    
OPEN   3 10 0 -1
200   100  
240   100  
240   60   
OPEN   3 10 0 -1
200   -100 
160   -100 
160   -60  
T0     0     0 0 60    10    0 2 140   10    0 16 PINSHORT
P-520  0     0 2 -80   0     0 2 0
T600   0     0 2 60    10    0 2 140   10    0 16 PINSHORT
P-520  0     0 2 -80   0     0 2 0
T600   -100  0 2 60    10    0 2 140   10    0 16 PINSHORT
P-520  0     0 2 -80   0     0 2 0

*END*