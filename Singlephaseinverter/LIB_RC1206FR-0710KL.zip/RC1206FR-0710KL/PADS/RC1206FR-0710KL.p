*PADS-LIBRARY-PART-TYPES-V9*

RC1206FR-0710KL RESC3116X65N I RES 7 1 0 0 0
TIMESTAMP 2026.06.09.22.10.20
"Mouser Part Number" 603-RC1206FR-0710KL
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/YAGEO/RC1206FR-0710KL?qs=%252BhB4WxZmbVEJV82xdVgRUw%3D%3D
"Manufacturer_Name" Yageo Group
"Manufacturer_Part_Number" RC1206FR-0710KL
"Description" Yageo 10k, 1206 (3216M) Thick Film SMD Resistor +/-1% 0.25W - RC1206FR-0710KL
"Datasheet Link" https://www.yageo.com/upload/media/product/app/datasheet/rchip/pyu-rc_group_51_rohs_l.pdf
"Geometry.Height" 0.65mm
GATE 1 2 0
RC1206FR-0710KL
1 0 U 1
2 0 U 2

*END*
*REMARK* SamacSys ECAD Model
16154743/2067606/2.50/2/3/Resistor
