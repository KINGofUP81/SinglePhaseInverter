*PADS-LIBRARY-PART-TYPES-V9*

ECW-FE2J105QD ECWFE2J105QD I CAP 7 1 0 0 0
TIMESTAMP 2026.06.09.22.26.10
"Mouser Part Number" 
"Mouser Price/Stock" 
"Manufacturer_Name" Panasonic
"Manufacturer_Part_Number" ECW-FE2J105QD
"Description" Cap Film 1uF 630V PP 10% (31 X 9 X 19mm) Radial Plastic Rectangular Can 27.5mm 105C Bag
"Datasheet Link" https://industrial.panasonic.com/cdbs/www-data/pdf/RDI0000/ast-ind-127757.pdf
"Geometry.Height" 19.5mm
GATE 1 2 0
ECW-FE2J105QD
1 0 U 1
2 0 U 2

*END*
*REMARK* SamacSys ECAD Model
15347963/2067606/2.50/2/2/Capacitor
