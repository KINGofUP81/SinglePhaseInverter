*PADS-LIBRARY-PART-TYPES-V9*

ECW-FE2J104JA ECWFE2J104JA I CAP 7 1 0 0 0
TIMESTAMP 2026.06.09.21.57.50
"Mouser Part Number" 667-ECW-FE2J104JA
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Panasonic/ECW-FE2J104JA?qs=wYonFgBYHKmYUwO8ni7ZdQ%3D%3D
"Manufacturer_Name" Panasonic
"Manufacturer_Part_Number" ECW-FE2J104JA
"Description" Film Capacitors 0.1uF 630VDC 5% MPP L/S=15mm
"Datasheet Link" 
"Geometry.Height" 11mm
GATE 1 2 0
ECW-FE2J104JA
1 0 U 1
2 0 U 2

*END*
*REMARK* SamacSys ECAD Model
15003435/2067606/2.50/2/4/Capacitor
