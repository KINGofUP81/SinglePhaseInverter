*PADS-LIBRARY-PART-TYPES-V9*

1140-681K-RC 1140681KRC I IND 7 1 0 0 0
TIMESTAMP 2026.06.06.17.24.36
"Mouser Part Number" 542-1140-681K-RC
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/JW-Miller/1140-681K-RC?qs=31V0VTPgyAWx7xkvlcwSyQ%3D%3D
"Manufacturer_Name" Bourns
"Manufacturer_Part_Number" 1140-681K-RC
"Description" Fixed Inductors 680uH +/-20%, 0.139, Irms=4.4A, Isat=7.9A
"Datasheet Link" https://www.bourns.com/data/global/pdfs/1140_series.pdf
"Geometry.Height" 26.162mm
GATE 1 2 0
1140-681K-RC
1 0 U 1
2 0 U 2

*END*
*REMARK* SamacSys ECAD Model
13335507/2067606/2.50/2/2/Inductor
