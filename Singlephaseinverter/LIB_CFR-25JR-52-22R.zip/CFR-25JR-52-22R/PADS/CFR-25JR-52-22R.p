*PADS-LIBRARY-PART-TYPES-V9*

CFR-25JR-52-22R RESAD1590W60L630D240 I RES 6 1 0 0 0
TIMESTAMP 2026.06.30.18.29.51
"Mouser Part Number" 603-CFR-25JR-52-22R
"Mouser Price/Stock" https://www.mouser.com/Search/Refine.aspx?Keyword=603-CFR-25JR-52-22R
"Manufacturer_Name" Yageo Group
"Manufacturer_Part_Number" CFR-25JR-52-22R
"Description" Carbon Film Resistors - Through Hole 22ohm 1/4W 5%
"Datasheet Link" https://componentsearchengine.com/Datasheets/1/CFR-25JR-52-22R.pdf
GATE 1 2 0
CFR-25JR-52-22R
1 0 U 1
2 0 U 2

*END*
*REMARK* SamacSys ECAD Model
1796095/2067606/2.50/2/3/Resistor
