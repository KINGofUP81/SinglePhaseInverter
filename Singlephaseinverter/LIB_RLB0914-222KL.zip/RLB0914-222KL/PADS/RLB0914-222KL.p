*PADS-LIBRARY-PART-TYPES-V9*

RLB0914-222KL RLB0914222KL I IND 7 1 0 0 0
TIMESTAMP 2026.06.30.19.03.09
"Mouser Part Number" 652-RLB0914-222KL
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Bourns/RLB0914-222KL?qs=AC4ivEYFOTCRlKiHK4JmQg%3D%3D
"Manufacturer_Name" Bourns
"Manufacturer_Part_Number" RLB0914-222KL
"Description" Fixed Inductors 2200uH 10%
"Datasheet Link" https://www.arrow.com/en/products/rlb0914-222kl/bourns
"Geometry.Height" 13mm
GATE 1 2 0
RLB0914-222KL
1 0 U 1
2 0 U 2

*END*
*REMARK* SamacSys ECAD Model
258421/2067606/2.50/2/4/Inductor
