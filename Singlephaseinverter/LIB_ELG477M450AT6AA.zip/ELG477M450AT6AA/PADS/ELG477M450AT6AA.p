*PADS-LIBRARY-PART-TYPES-V9*

ELG477M450AT6AA CAPPRD1000W160D3550H5200 I CAP 7 1 0 0 0
TIMESTAMP 2026.06.09.20.44.32
"Mouser Part Number" 80-ELG477M450AT6AA
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/KEMET/ELG477M450AT6AA?qs=285CF8bfA1RxuYsYDkcnsA%3D%3D
"Manufacturer_Name" Yageo Group
"Manufacturer_Part_Number" ELG477M450AT6AA
"Description" Snap-In, Aluminum Electrolytic
"Datasheet Link" https://www.yageogroup.com/content/datasheet/asset/file/KEM_A4021_ELG
"Geometry.Height" 52mm
GATE 1 2 0
ELG477M450AT6AA
1 0 U +
2 0 U -

*END*
*REMARK* SamacSys ECAD Model
396137/2067606/2.50/2/2/Capacitor Polarised
