*PADS-LIBRARY-PART-TYPES-V9*

SMCJ440A DIOM7959X262N I DIO 7 1 0 0 0
TIMESTAMP 2026.06.10.19.35.53
"Mouser Part Number" 576-SMCJ440A
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Littelfuse/SMCJ440A?qs=JJML70Qc14sOgeRMsCwdfA%3D%3D
"Manufacturer_Name" LITTELFUSE
"Manufacturer_Part_Number" SMCJ440A
"Description" ESD Suppressors / TVS Diodes 1.5kW 440V 5% Uni-Directional
"Datasheet Link" https://www.littelfuse.com/~/media/electronics/datasheets/tvs_diodes/littelfuse_tvs_diode_smcj_datasheet.pdf.pdf
"Geometry.Height" 2.62mm
GATE 1 2 0
SMCJ440A
1 0 U K
2 0 U A

*END*
*REMARK* SamacSys ECAD Model
989743/2067606/2.50/2/3/TVS Diode (Uni-directional)
