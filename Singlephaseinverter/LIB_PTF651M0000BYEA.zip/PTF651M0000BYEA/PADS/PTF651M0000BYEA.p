*PADS-LIBRARY-PART-TYPES-V9*

PTF651M0000BYEA RESAD2425W64L953D368 I RES 6 1 0 0 0
TIMESTAMP 2026.06.30.18.17.55
"Mouser Part Number" 71-PTF651M0000BYEA
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Vishay-Dale/PTF651M0000BYEA?qs=pdTTgkPlST4VILgW7yzSdg%3D%3D
"Manufacturer_Name" Vishay
"Manufacturer_Part_Number" PTF651M0000BYEA
"Description" Metal Film Resistors - Through Hole 1M    OHM .1%   10PPM  1/4W
"Datasheet Link" https://www.vishay.com/docs/31019/ptf.pdf
GATE 1 2 0
PTF651M0000BYEA
1 0 U 1
2 0 U 2

*END*
*REMARK* SamacSys ECAD Model
17959222/2067606/2.50/2/3/Resistor
