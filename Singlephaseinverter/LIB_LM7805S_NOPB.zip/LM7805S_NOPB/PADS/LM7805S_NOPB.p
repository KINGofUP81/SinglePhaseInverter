*PADS-LIBRARY-PART-TYPES-V9*

LM7805S_NOPB KTT0003B I ANA 6 1 0 0 0
TIMESTAMP 2026.06.12.13.29.27
"Mouser Part Number" 595-LM7805S/NOPB
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Texas-Instruments/LM7805S-NOPB?qs=9V2QonpqdTu8D%252Bva6DasHQ%3D%3D
"Manufacturer_Name" Texas Instruments
"Manufacturer_Part_Number" LM7805S/NOPB
"Description" 1.5-A, Wide VIN Fixed Voltage Regulators
"Datasheet Link" http://www.ti.com/lit/gpn/lm7800
GATE 1 4 0
LM7805S_NOPB
1 0 L INPUT
2 0 G GND_1
3 0 S OUTPUT
4 0 G GND_2

*END*
*REMARK* SamacSys ECAD Model
364415/2067606/2.50/4/4/Integrated Circuit
