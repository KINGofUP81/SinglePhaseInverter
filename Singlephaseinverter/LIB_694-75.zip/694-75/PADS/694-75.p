*PADS-LIBRARY-PART-TYPES-V9*

694-75 69475 I ANA 7 1 0 0 0
TIMESTAMP 2026.07.13.13.47.19
"Mouser Part Number" 567-694-75
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Wakefield-Vette/694-75?qs=vLWxofP3U2w6pSifxx%252Blvw%3D%3D
"Manufacturer_Name" Wakefield Thermal
"Manufacturer_Part_Number" 694-75
"Description" Heat Sinks Heat Sink, Board Mount, TO247, Integrated Clip, Black Anodized, Solder to PCB Attachment, 75mm Length, 35.05mm Height, 22mm Width
"Datasheet Link" https://wakefieldthermal.com/content/data_sheets/690%20%281%29.pdf
"Geometry.Height" 35.05mm
GATE 1 2 0
694-75
1 0 U 1
2 0 U 2

*END*
*REMARK* SamacSys ECAD Model
2195555/2067606/2.50/2/3/Hardware
